# account/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.giris_yap, name='giris'),
    path('baskan/panel/', views.baskan_paneli, name='baskan_paneli'),
    path('sekreter/panel/', views.sekreter_paneli, name='sekreter_paneli'),
    path('ogretim/panel/', views.ogretim_paneli, name='ogretim_paneli'),
    path('logout/', views.cikis_yap, name='logout'),
    path('kullanici-ekle/', views.kullanici_ekle, name='kullanici_ekle'),
    path('yetkilendir/', views.kullanici_yetkilendir, name='kullanici_yetkilendir'),
    path('akademik-giris/', views.akademik_giris, name='akademik_giris'),
    path('idari-giris/', views.idari_giris, name='idari_giris'),

]