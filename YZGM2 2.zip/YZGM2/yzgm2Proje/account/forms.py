from django import forms
from django.contrib.auth import get_user_model

User = get_user_model()

class KullaniciEkleForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput(), label="Şifre")

    class Meta:
        model = User
        fields = ['first_name', 'email', 'username', 'password']  # Dikkat: role yok!

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data['password'])

        # Role boş gideceği için istersen varsayılan verebilirsin:
        # user.role = 'ogretim'  ← örneğin

        if commit:
            user.save()
        return user
