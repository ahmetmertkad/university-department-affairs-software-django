from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.contrib.auth import logout
from django.contrib.messages import get_messages


from django.shortcuts import render

def giris_yap(request):
    return render(request, 'account/giris.html')


from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden
from django.shortcuts import render

def rol_kontrol(user, rol):
    return user.is_authenticated and user.role == rol

@login_required
def baskan_paneli(request):
    if not rol_kontrol(request.user, 'baskan'):
        return HttpResponseForbidden("Bu sayfaya erişim izniniz yok.")
    return render(request, 'account/baskan_paneli.html')

@login_required
def sekreter_paneli(request):
    if not rol_kontrol(request.user, 'sekreter'):
        return HttpResponseForbidden("Bu sayfaya erişim izniniz yok.")
    return render(request, 'account/sekreter_paneli.html')

@login_required
def ogretim_paneli(request):
    if not rol_kontrol(request.user, 'ogretim'):
        return HttpResponseForbidden("Bu sayfaya erişim izniniz yok.")
    return render(request, 'account/ogretim_paneli.html')

@login_required
def cikis_yap(request):
    logout(request)
    return redirect('giris')

from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden
from django.shortcuts import render, redirect
from .forms import KullaniciEkleForm
from .models import CustomUser

@login_required
def kullanici_ekle(request):
    if request.user.role not in ['sekreter', 'baskan']:
        return HttpResponseForbidden("Bu sayfa sadece bölüm başkanı ve sekreter içindir.")
    
    if request.method == 'POST':
        form = KullaniciEkleForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('kullanici_ekle')
    else:
        form = KullaniciEkleForm()

    users = CustomUser.objects.all()
    return render(request, 'account/kullaniciEkle.html', {'form': form, 'users': users})

@login_required
def kullanici_yetkilendir(request):
    if request.user.role not in ['baskan']:
        return HttpResponseForbidden("Bu sayfa sadece bölüm başkanı içindir.")

    kullanicilar = CustomUser.objects.exclude(id=request.user.id)  # kendini listeleme

    if request.method == 'POST':
        user_id = request.POST.get('kullanici')
        rol = request.POST.get('rol')
        try:
            user = CustomUser.objects.get(id=user_id)
            user.role = rol
            user.save()
            messages.success(request, f"{user.get_full_name()} kullanıcısının rolü başarıyla güncellendi.")
        except CustomUser.DoesNotExist:
            messages.error(request, "Kullanıcı bulunamadı.")
        return redirect('kullanici_yetkilendir')

    return render(request, 'account/kullanici_yetkilendir.html', {'kullanicilar': kullanicilar})

def akademik_giris(request):
    if request.method == 'GET':
        list(get_messages(request))  # önceki uyarıları temizle

    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)

        if user is not None:
            if user.role in ['ogretim', 'baskan']:
                login(request, user)
                return redirect('ogretim_paneli' if user.role == 'ogretim' else 'baskan_paneli')
            else:
                messages.error(request, "Bu giriş sadece akademik personel içindir.")
                return redirect('akademik_giris')  # doğru sayfaya yönlendir
        else:
            messages.error(request, "Kullanıcı adı veya şifre hatalı.")
            return redirect('akademik_giris')

    return render(request, 'account/akademik_login.html')

def idari_giris(request):
    if request.method == 'GET':
        list(get_messages(request))  # önceki uyarıları temizle

    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)

        if user is not None:
            if user.role in ['baskan', 'sekreter']:
                login(request, user)
                return redirect('sekreter_paneli' if user.role == 'sekreter' else 'baskan_paneli')
            else:
                messages.error(request, "Bu giriş sadece idari personel içindir.")
                return redirect('idari_giris')  # doğru sayfaya yönlendir
        else:
            messages.error(request, "Kullanıcı adı veya şifre hatalı.")
            return redirect('idari_giris')

    return render(request, 'account/idari_login.html')




