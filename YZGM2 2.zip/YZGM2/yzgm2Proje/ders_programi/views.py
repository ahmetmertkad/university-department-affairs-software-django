from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden
from .forms import DersForm
from .models import Ders
from .models import Derslik
from .forms import DersZamaniForm
from .models import DersZamani
from .models import DerslikAtama
from .forms import DerslikAtamaForm
from django.contrib import messages
from .forms import OgretimAtamaForm
from .models import OgretimAtama

@login_required
def ders_ekle(request):
    if request.user.role not in ['sekreter', 'baskan']:
        return HttpResponseForbidden("Bu sayfa sadece bölüm başkanı ve sekreter içindir.")

    dersler = Ders.objects.all()
    if request.method == 'POST':
        form = DersForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('ders_ekle')
    else:
        form = DersForm()
    
    return render(request, 'ders_programi/ders_ekle.html', {'form': form, 'dersler': dersler})

from django.shortcuts import get_object_or_404

@login_required
def ders_sil(request, pk):
    if request.user.role not in ['sekreter', 'baskan']:
        return HttpResponseForbidden("Bu sayfa sadece bölüm başkanı ve sekreter içindir.")

    ders = get_object_or_404(Ders, pk=pk)
    ders.delete()
    return redirect('ders_ekle')

from .forms import DerslikForm

@login_required
def derslik_olustur(request):
    if request.user.role not in ['sekreter', 'baskan']:
        return HttpResponseForbidden("Bu sayfa sadece bölüm başkanı ve sekreter içindir.")

    if request.method == 'POST':
        form = DerslikForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('derslik_olustur')
    else:
        form = DerslikForm()

    derslikler = Derslik.objects.all()
    return render(request, 'ders_programi/derslik_olustur.html', {
        'form': form,
        'derslikler': derslikler
    })

@login_required
def derslik_sil(request, pk):
    if request.user.role not in ['sekreter', 'baskan']:
        return HttpResponseForbidden("Bu sayfa sadece bölüm başkanı ve sekreter içindir.")
    
    derslik = get_object_or_404(Derslik, pk=pk)
    derslik.delete()
    return redirect('derslik_olustur')  # URL adın buysa

@login_required
def ders_zamani_ekle(request):
    if request.user.role not in ['sekreter', 'baskan']:
        return HttpResponseForbidden("Bu sayfa sadece bölüm başkanı ve sekreter içindir.")
    
    if request.method == 'POST':
        form = DersZamaniForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('ders_zamani_ekle')
    else:
        form = DersZamaniForm()

    zamanlar = DersZamani.objects.all()
    return render(request, 'ders_programi/ders_zamani_ekle.html', {'form': form, 'zamanlar': zamanlar})

@login_required
def ders_zamani_sil(request, pk):
    ders_zamani = get_object_or_404(DersZamani, pk=pk)
    
    # Sadece sekreter silebilsin (isteğe bağlı)
    if request.user.role not in ['sekreter', 'baskan']:
        return HttpResponseForbidden("Bu sayfa sadece bölüm başkanı ve sekreter içindir.")

    ders_zamani.delete()
    return redirect('ders_zamani_ekle')  # veya ilgili view'in adı neyse


from django.contrib import messages

def derslik_atama(request):
    if request.user.role not in ['sekreter', 'baskan']:
        return HttpResponseForbidden("Bu sayfa sadece bölüm başkanı ve sekreter içindir.")

    atamalar = DerslikAtama.objects.select_related('ders_zamani', 'derslik')

    if request.method == 'POST':
        form = DerslikAtamaForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Atama başarılı.")
            return redirect('derslik_atama')
        else:
            for field, error_list in form.errors.items():
                for error in error_list:
                    messages.error(request, f"{field.capitalize()}: {error}")
    else:
        form = DerslikAtamaForm()

    return render(request, 'ders_programi/derslik_atama.html', {
        'form': form,
        'atamalar': atamalar,
    })

def derslik_atama_sil(request, pk):
    if request.user.role not in ['sekreter', 'baskan']:
        return HttpResponseForbidden("Bu sayfa sadece bölüm başkanı ve sekreter içindir.")
    
    atama = get_object_or_404(DerslikAtama, pk=pk)
    atama.delete()
    messages.success(request, "Atama silindi.")
    return redirect('derslik_atama')

@login_required
def ogretim_atama(request):
    if request.user.role not in ['sekreter', 'baskan']:
        return HttpResponseForbidden("Bu işlem yalnızca yetkili kullanıcılar içindir.")

    if request.method == 'POST':
        form = OgretimAtamaForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Ders ataması başarıyla yapıldı.")
            return redirect('ogretim_atama')
    else:
        form = OgretimAtamaForm()

    atamalar = OgretimAtama.objects.select_related('ders', 'ogretim_elemani')
    zamanlar = DersZamani.objects.select_related('ders')

    return render(request, 'ders_programi/ogretim_atama.html', {
        'form': form,
        'atamalar': atamalar,
        'zamanlar': zamanlar,  # 👈 eklendi
    })


@login_required
def ogretim_atama_sil(request, pk):
    if request.user.role not in ['sekreter', 'baskan']:
        return HttpResponseForbidden("Bu işlem yalnızca yetkili kullanıcılar içindir.")
    
    atama = get_object_or_404(OgretimAtama, pk=pk)
    atama.delete()
    messages.success(request, "Atama başarıyla silindi.")
    return redirect('ogretim_atama')



@login_required
def ogretim_ders_programi(request):
    if request.user.role != 'ogretim':
        return HttpResponseForbidden("Bu sayfa sadece öğretim elemanları içindir.")

    # Kullanıcıya atanmış dersler
    atamalar = OgretimAtama.objects.filter(ogretim_elemani=request.user).select_related('ders')

    # O derslere ait zaman bilgileri
    zamanlar = DersZamani.objects.filter(ders__in=[a.ders for a in atamalar])

    return render(request, 'ders_programi/ogretimgDersleriGor.html', {
        'atamalar': atamalar,
        'zamanlar': zamanlar
    })