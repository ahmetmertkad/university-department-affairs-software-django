from django import forms
from .models import Ders
from .models import Derslik
from django.core.exceptions import ValidationError

class DersForm(forms.ModelForm):
    class Meta:
        model = Ders
        fields = ['kod', 'ad', 'kredi']
        labels = {
            'kod': 'Ders Kodu',
            'ad': 'Ders Adı',
            'kredi': 'Kredi',
        }



class DerslikForm(forms.ModelForm):
    class Meta:
        model = Derslik
        fields = ['ad', 'kapasite']
        widgets = {
            'ad': forms.TextInput(attrs={'class': 'form-control'}),
            'kapasite': forms.NumberInput(attrs={'class': 'form-control', 'min': 1}),
        }

from django import forms
from .models import DersZamani

from django import forms
from .models import DersZamani

class DersZamaniForm(forms.ModelForm):
    class Meta:
        model = DersZamani
        fields = ['ders', 'gun', 'baslangic_saat', 'bitis_saat']
        widgets = {
            'baslangic_saat': forms.TimeInput(attrs={'type': 'time'}),
            'bitis_saat': forms.TimeInput(attrs={'type': 'time'}),
        }

    def clean(self):
        cleaned_data = super().clean()
        ders = cleaned_data.get('ders')
        gun = cleaned_data.get('gun')
        baslangic = cleaned_data.get('baslangic_saat')
        bitis = cleaned_data.get('bitis_saat')

        # Temel alanlar eksikse kontrol etmeden çık
        if not all([ders, gun, baslangic, bitis]):
            return cleaned_data

        # 1. Aynı ders için aynı gün zaman çakışma kontrolü
        qs = DersZamani.objects.filter(ders=ders, gun=gun)
        for kayit in qs:
            if (
                baslangic < kayit.bitis_saat and
                bitis > kayit.baslangic_saat
            ):
                raise ValidationError("Bu ders bu gün ve saatte başka bir zaman aralığında zaten tanımlanmış.")

        # 2. Aynı sınıfa ait dersler ile zaman çakışması kontrolü
        try:
            sinif_numarasi = ders.kod[3]  # Örn: YZM101 → '1' (1. sınıf)
        except IndexError:
            raise ValidationError("Ders kodu hatalı. Kod en az 4 karakterli olmalı (örn. YZM101).")

        ayni_sinif_dersleri = Ders.objects.filter(kod__regex=f'^...{sinif_numarasi}').exclude(id=ders.id)
        zamanlar = DersZamani.objects.filter(ders__in=ayni_sinif_dersleri, gun=gun)

        for z in zamanlar:
            if baslangic < z.bitis_saat and bitis > z.baslangic_saat:
                raise ValidationError(
                    f"{z.ders.kod} ile zaman çakışması var. Aynı sınıfa ({sinif_numarasi}. sınıf) ait dersler aynı saatte olamaz."
                )

        return cleaned_data
from django.shortcuts import render, redirect
from .forms import DersZamaniForm
from .models import DersZamani
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden

from django import forms
from .models import DerslikAtama

from django.core.exceptions import ValidationError

class DerslikAtamaForm(forms.ModelForm):
    class Meta:
        model = DerslikAtama
        fields = ['ders_zamani', 'derslik']

    def clean(self):
        cleaned_data = super().clean()
        derslik = cleaned_data.get('derslik')
        zaman = cleaned_data.get('ders_zamani')

        if derslik and zaman:
            # Aynı derslik, aynı gün ve saat çakışıyor mu?
            if DerslikAtama.objects.filter(
                derslik=derslik,
                ders_zamani__gun=zaman.gun,
                ders_zamani__baslangic_saat__lt=zaman.bitis_saat,
                ders_zamani__bitis_saat__gt=zaman.baslangic_saat
            ).exists():
                raise ValidationError("Bu derslik bu saat aralığında zaten bir derse atanmış.")
            


from django import forms
from .models import OgretimAtama
from account.models import CustomUser

class OgretimAtamaForm(forms.ModelForm):
    class Meta:
        model = OgretimAtama
        fields = ['ders', 'ogretim_elemani']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['ogretim_elemani'].queryset = CustomUser.objects.filter(role='ogretim')

    def clean(self):
        cleaned_data = super().clean()
        ogretim_elemani = cleaned_data.get('ogretim_elemani')
        ders = cleaned_data.get('ders')

        if ogretim_elemani and ders:
            try:
                zaman = DersZamani.objects.get(ders=ders)

                atamalar = OgretimAtama.objects.filter(
                    ogretim_elemani=ogretim_elemani,
                    ders__derszamani__gun=zaman.gun,
                    ders__derszamani__baslangic_saat__lt=zaman.bitis_saat,
                    ders__derszamani__bitis_saat__gt=zaman.baslangic_saat
                )

                if self.instance.pk:
                    atamalar = atamalar.exclude(pk=self.instance.pk)

                if atamalar.exists():
                    raise ValidationError(
                        f"{ogretim_elemani.first_name} {ogretim_elemani.last_name} adlı öğretim elemanının bu saatlerde başka dersi var!"
                    )

            except DersZamani.DoesNotExist:
                raise ValidationError("Bu dersin zaman bilgisi tanımlı değil.")

        return cleaned_data