import pandas as pd
from django.core.management.base import BaseCommand
from ders_programi.models import Student, Ders, OgrenciDers

class Command(BaseCommand):
    help = "Excel'den öğrenci ve ders ilişkisi aktarır."

    def add_arguments(self, parser):
        parser.add_argument('excel_dosyasi', type=str, help="Excel dosyasının yolu")

    def handle(self, *args, **kwargs):
        dosya = kwargs['excel_dosyasi']
        try:
            df = pd.read_excel(dosya)
        except Exception as e:
            self.stdout.write(self.style.ERROR(f"Excel okunamadı: {e}"))
            return

        for _, row in df.iterrows():
            try:
                student, _ = Student.objects.get_or_create(
                    ogrenci_no=row['ogrenci_no'],
                    defaults={
                        'ad': row['ad'],
                        'soyad': row['soyad']
                    }
                )

                ders = Ders.objects.get(kod=row['ders_kodu'])

                OgrenciDers.objects.get_or_create(
                    ogrenci=student,
                    ders=ders
                )
            except Ders.DoesNotExist:
                self.stdout.write(self.style.WARNING(f"Ders bulunamadı: {row['ders_kodu']}"))
            except Exception as e:
                self.stdout.write(self.style.ERROR(f"Hata: {e}"))

        self.stdout.write(self.style.SUCCESS("Aktarım tamamlandı."))
