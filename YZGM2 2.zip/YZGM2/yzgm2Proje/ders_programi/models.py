from django.db import models

class Ders(models.Model):
    kod = models.CharField(max_length=10)
    ad = models.CharField(max_length=100)
    kredi = models.PositiveIntegerField()

    def __str__(self):
        return f"{self.kod} - {self.ad}"


class Derslik(models.Model):
    ad = models.CharField(max_length=100)
    kapasite = models.PositiveIntegerField()

    def __str__(self):
        return f"{self.ad} - {self.kapasite} kişi"
    
from django.db import models
from ders_programi.models import Ders  # varsa

class DersZamani(models.Model):
    GUN_CHOICES = [
        ('Pzt', 'Pazartesi'),
        ('Sal', 'Salı'),
        ('Car', 'Çarşamba'),
        ('Per', 'Perşembe'),
        ('Cum', 'Cuma'),
    ]

    ders = models.ForeignKey(Ders, on_delete=models.CASCADE)
    gun = models.CharField(max_length=10, choices=GUN_CHOICES)
    baslangic_saat = models.TimeField()
    bitis_saat = models.TimeField()

    def __str__(self):
        return f"{self.ders.ad} - {self.gun} ({self.baslangic_saat} - {self.bitis_saat})"
    

class DerslikAtama(models.Model):
    ders_zamani = models.OneToOneField(DersZamani, on_delete=models.CASCADE)
    derslik = models.ForeignKey(Derslik, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.ders_zamani} -> {self.derslik}"
    

from django.db import models
from account.models import CustomUser  # Öğretim elemanı için
from .models import Ders  # Zaten var

class OgretimAtama(models.Model):
    ders = models.ForeignKey(Ders, on_delete=models.CASCADE)
    ogretim_elemani = models.ForeignKey(CustomUser, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.ders.ad} → {self.ogretim_elemani.get_full_name()}"
    
from django.db import models

from django.db import models

class Student(models.Model):
    ogrenci_no = models.CharField(max_length=20, unique=True)
    ad = models.CharField(max_length=100)
    soyad = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.ad} {self.soyad} ({self.ogrenci_no})"
    
class OgrenciDers(models.Model):
    ogrenci = models.ForeignKey(Student, on_delete=models.CASCADE)
    ders = models.ForeignKey(Ders, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.ogrenci} → {self.ders}"
