from django.urls import path
from . import views

urlpatterns = [
    path('ekle/', views.ders_ekle, name='ders_ekle'),
    path('sil/<int:pk>/', views.ders_sil, name='ders_sil'),
    path('derslik-olustur/', views.derslik_olustur, name='derslik_olustur'),
    path('derslik-sil/<int:pk>/', views.derslik_sil, name='derslik_sil'),
    path('ders-zaman-ata/',views.ders_zamani_ekle,name='ders_zamani_ekle'),
    path('ders-zamani-sil/<int:pk>/', views.ders_zamani_sil, name='ders_zamani_sil'),  # 👈 burası eklendi
    path('derslik-atama/', views.derslik_atama, name='derslik_atama'),
    path('derslik-atama/sil/<int:pk>/', views.derslik_atama_sil, name='derslik_atama_sil'),
    path('ogretim-atama/', views.ogretim_atama, name='ogretim_atama'),
    path('ogretim-atama/sil/<int:pk>/', views.ogretim_atama_sil, name='ogretim_atama_sil'),
    path('ogretim/ders-programi/', views.ogretim_ders_programi, name='ogretim_ders_programi'),

]
